# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: spectator-api.dev (MySQL 5.6.19-0ubuntu0.14.04.1)
# Database: homestead
# Generation Time: 2015-07-25 17:03:15 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table creator_game
# ------------------------------------------------------------

DROP TABLE IF EXISTS `creator_game`;

CREATE TABLE `creator_game` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table creators
# ------------------------------------------------------------

DROP TABLE IF EXISTS `creators`;

CREATE TABLE `creators` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subscribers` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthday` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `creators_channel_id_unique` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table failed_jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table games
# ------------------------------------------------------------

DROP TABLE IF EXISTS `games`;

CREATE TABLE `games` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `api_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `franchise` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rating` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `games_api_id_unique` (`api_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `games` WRITE;
/*!40000 ALTER TABLE `games` DISABLE KEYS */;

INSERT INTO `games` (`id`, `api_id`, `title`, `description`, `franchise`, `year`, `rating`, `image_url`, `created_at`, `updated_at`)
VALUES
	(1,41484,'The Witcher 3: Wild Hunt','CD Projekt RED\'s third Witcher combines the series\' non-linear storytelling with a sprawling open world that concludes the saga of Geralt of Rivia.','Franchise not found','2015','ESRB: M','http://static.giantbomb.com/uploads/scale_large/0/3699/2698809-the+witcher+3+-+wild+hunt+v7.jpg','2015-07-25 16:59:54','2015-07-25 16:59:54');

/*!40000 ALTER TABLE `games` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `jobs`;

CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_reserved_at_index` (`queue`,`reserved`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`migration`, `batch`)
VALUES
	('2014_10_12_000000_create_users_table',1),
	('2014_10_12_100000_create_password_resets_table',1),
	('2015_06_23_172857_create_games_table',1),
	('2015_06_23_174258_create_videos_table',1),
	('2015_06_23_174326_create_creators_table',1),
	('2015_06_23_174354_create_series_table',1),
	('2015_06_27_181017_create_series_videos_table',1),
	('2015_07_11_193745_create_creators_games_table',1),
	('2015_07_19_125847_create_failed_jobs_table',1),
	('2015_07_19_125908_create_jobs_table',1),
	('2015_07_22_094036_create_roles_table',1),
	('2015_07_22_094105_create_role_user_table',1);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table role_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `role_user`;

CREATE TABLE `role_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;

INSERT INTO `role_user` (`id`, `role_id`, `user_id`, `created_at`, `updated_at`)
VALUES
	(1,1,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),
	(3,2,2,'0000-00-00 00:00:00','0000-00-00 00:00:00');

/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;

INSERT INTO `roles` (`id`, `name`, `level`, `created_at`, `updated_at`)
VALUES
	(1,'anon','anon','0000-00-00 00:00:00','0000-00-00 00:00:00'),
	(2,'user','user','0000-00-00 00:00:00','0000-00-00 00:00:00'),
	(3,'admin','admin','0000-00-00 00:00:00','0000-00-00 00:00:00');

/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table series
# ------------------------------------------------------------

DROP TABLE IF EXISTS `series`;

CREATE TABLE `series` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `playlist_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `game_id` int(11) NOT NULL,
  `creator_id` int(11) NOT NULL,
  `published_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `series_playlist_id_unique` (`playlist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `series` WRITE;
/*!40000 ALTER TABLE `series` DISABLE KEYS */;

INSERT INTO `series` (`id`, `name`, `channel_id`, `playlist_id`, `game_id`, `creator_id`, `published_at`, `created_at`, `updated_at`)
VALUES
	(1,'Mr. Odd Plays The Witcher 3: Wild Hunt','UCdAy0KqpdA2Lp2_Qp0yNk2g','PLj_Goi54wf0fQPWB_hjgmd3i1yIXeLXHI',1,0,'2015-05-19 01:44:18','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(2,'Witcher 3: Wild Hunt - Let\'s Play [Death March]','UCnSuI6Qe57RSyIXn2Q-2Emg','PLkz8U6R3Ri-ftG-xYODV1T6e8iYa-_1Kv',1,0,'2015-05-19 06:20:49','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(3,'Let\'s Play The Witcher 3 Gameplay German Deutsch Walkthrough','UCVRO6HgS557J5ShfwqiwHpQ','PL0fSTml3BFP2cwvwfQ9A1eEdVhoysbfyc',1,0,'2015-05-16 14:57:48','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(4,'The Witcher 3: Wild Hunt','UCYJ61XIK64sp6ZFFS8sctxw','PLGWGc5dfbzn-HX1ejbEwa2l2xMMs_9iNe',1,0,'2015-05-17 08:27:27','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(5,'The Witcher 3: Wild Hunt - Let\'s Play','UCOlvhCZQc3P9WuD7486BVFw','PLzUNBD-xWMd1LFUcKYAVcDgR5zPLvilyR',1,0,'2015-05-19 02:58:19','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(6,'The Witcher 3: Wild Hunt','UCp56TyePXVBOaMIsCl1dYyQ','PL5KHd4q0vXyzv8tcyv8JZGmU2kiiBv2rd',1,0,'2015-05-16 10:11:54','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(7,'Witcher 3: Wild Hunt','UCF_k3-4jHtT6aJkzQ9gnIeQ','PLNO4FREMyM4fUEtf-GTxjCPbZRPaTejJM',1,0,'2015-05-19 14:14:04','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(8,'Let´s Play : The Witcher 3 -  Wild Hunt / German - Full HD','UC2jx6fwv7RZikTpL3PyuD5g','PLGm8qxp5YwNQuKIAnxT6fDAfqpF6Cz1kN',1,0,'2015-05-18 06:50:05','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(9,'Let\'s Play: The Witcher 3','UCTHnzuUEe_zTtBMV7XV9NOA','PLuIMugRhz2hvgvzUJkCmpkmXipA2dtL7K',1,0,'2015-05-16 09:26:49','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(10,'Let\'s Play The witcher 3: Wild Hunt [German] [Blind] [PC] [ultra settings] [ultra graphics] [60 fps] - Ichbissak','UC5nh4EfXRWPGD0uFSAm7t-g','PLTZ1PyifRQr2CFk1Ya8vkF3XtEf7-oARa',1,0,'2015-05-20 11:20:42','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(11,'The Witcher 3','UCqwGaUvq_l0RKszeHhZ5leA','PL5JK9SjdCJp-rdOT368HZigUP39g1GzUA',1,0,'2015-05-17 19:55:25','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(12,'THE WITCHER 3 Gameplay German PC | Let\'s Play The Witcher 3 Wild Hunt mit SiriuS ULTRA','UCTaye30CfBY0NmjlxDTapwg','PLi8NbLjC-CITq7G8JKJgzZzXowcIgFxMw',1,0,'2015-05-18 17:16:05','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(13,'Ведьмак 3: Дикая Охота (The Witcher 3: Wild Hunt)','UCENeeLCbbDNAP-664-t26FA','PLkJoTOgcypA-pXu7ILqwgl71yY-ObVtFm',1,0,'2015-05-18 17:47:30','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(14,'Let\'s Play the Witcher 3','UCI6keWArpxmfeiuAATv7jZw','PLQDWoXFQ-YLrUP3dIHXAxqnCyZ3_sLbjX',1,0,'2015-05-20 19:39:27','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(15,'Witcher 3 - The Wild Hunt (Let\'s Play)','UCB-UY_HpZgYMfkYi2Xxs-lA','PLk6W1KxWnn5AQEt_pr1G1JJnkCe5kVvl5',1,0,'2015-05-23 18:21:28','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(16,'Let\'s Play The Witcher 2 Assassins of Kings Enhanced Edition','UCdAy0KqpdA2Lp2_Qp0yNk2g','PLj_Goi54wf0fCfQc-w8rgj2hUaHNOtopX',1,0,'2013-07-25 17:28:47','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(17,'Lets Play The Witcher 3 Wild Hunt (Blut, Schweiss und Tränen!) German','UCy3QhVQEXHPrOBmciZuoVWw','PLQGVMHAl1FAfqWjCfAIByB4SWgxCz6Mcm',1,0,'2015-05-20 22:26:52','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(18,'The Witcher 3: The Wild Hunt - Let\'s Play [Death March, PC]','UCLNt-CPvjnIvFiw9iNpJA3g','PLzfpNfoBVWt3V5xRReqnpe3bhtBhKgIE0',1,0,'2015-05-25 06:37:17','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(19,'Let\'s Play The Witcher 3 Wild Hunt','UCOTyb6e_v9cz2Bu7VzFW7tg','PLT5cw0HwssyrWIbUY98Zl8OCRagc16oWq',1,0,'2015-05-16 13:53:10','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(20,'The Witcher 3 - Wild Hunt ★ Let\'s Play','UCQMlVxlDDx1tPvReqSGeOKQ','PLbfvXlbt55EkH6U1EoGJpzTmT4wJmwU4t',1,0,'2015-05-20 07:00:21','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(21,'◄► THE WITCHER 3 ♦ LET\'S PLAY EN HARD GAMEPLAY FR SKYYART','UC8g5sJFyraYb4Xl_lRHW-Jg','PLwto14mNwv8_K3L2eTJZJb4kUTj1oxscp',1,0,'2015-05-25 14:30:15','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(22,'The Witcher 3 : Wild Hunt - Let\'s Play  [FR]','UCgZ5fgcukeTLsF8GzkZJbqA','PLZia13CUI72mXOWZKaIiUE4pGyEYVzbfT',1,0,'2015-05-20 15:59:01','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(23,'The Witcher 3 Wild Hunt Let\'s Play Deutsch / Gameplay German','UC0DXHDRUNnB6xgtPtz7ZVVg','PLV2-Nbw-zbymitXLEWy_fyYfg8Muf3zWu',1,0,'2015-05-19 22:07:38','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(24,'The Witcher 3 Wild Hunt / Bosse / Endgegner (Let\'s Play/Deutsch/German)','UC0DXHDRUNnB6xgtPtz7ZVVg','PLV2-Nbw-zbyn8BX0UJgDmDlAJRUaI3ZCu',1,0,'2015-06-10 07:38:50','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(25,'Let\'s Play The Witcher 3 : Wild Hunt FR - Difficulté Marche de la Mort','UCKdnXfn22j-BIlrn2xDHemA','PLLJiBWJ3jMkrYOLtpVRepvKBj6NTT3hkK',1,0,'2015-05-19 08:16:43','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(26,'Let\'s Play The Witcher 3: Wild Hunt','UC8wyx9sL0X6XG5Tv4bTRe0w','PLVbFomEinoLSwzSQc620LTZQVkhHa2EDX',1,0,'2015-05-16 14:30:45','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(27,'The Witcher 3 : Wild Hunt','UCcUgS69ow5IiAjEdCqVFi9w','PLGP5N6BDD-UjX968F-kvGSXW-Dg249dDt',1,0,'2015-05-19 04:58:45','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(28,'The Witcher 3: Wild Hunt with Jesse Cox','UCjBQdvGSXzVA0b2mZ9lvghw','PL2n4kAHlamkSgUgQODT5k_40imVRtC0NY',1,0,'2015-05-20 01:38:20','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(29,'Let\'s Play The Witcher 3 Wild Hunt','UCREnYwVcTg0zR0QFmrh8TUQ','PLsBboZnr_JjuzZo5J-_dzTtNcPwOIJYSd',1,0,'2015-05-23 08:33:22','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(30,'Let\'s Play The Witcher 3: Wild Hunt','UCgb2XE8t_jCIpAZCAw1K1hA','PLbkOTslh_i1bXKUIYjAued6_IEvHqS5Yj',1,0,'2015-05-19 01:38:29','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(31,'Let\'s Play The Witcher 3 (deutsch)','UCjdQpI48tjnCs28XqKYWEmw','PLF8AY3Xr8tpcmGoOmr9SaNwX1FNXIaFHH',1,0,'2014-08-15 12:54:13','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(32,'The Witcher 3','UCMELMEuQqmxTqM4_ArhHPjQ','PL3Tn4a0sgY3KrXiZQyHUUM0mGvS7VHlW3',1,0,'2015-05-08 08:01:07','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(33,'Witcher 3 Let\'s Play','UCzdEaw2-l2e0L1EiGN3HjDw','PL852AT2GZISxniRzPXthiEwDnkam6pmqR',1,0,'2015-06-19 16:41:51','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(34,'Let\'s Play► The Witcher 3: Wild Hunt','UCAr90o4w2_b_A6oNa16MWUA','PL1sFc3mXLe7tMJV60DDgyDQrzB4FDaAP-',1,0,'2015-05-20 01:13:49','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(35,'Let\'s Play The Witcher 3 [Gronkh}{German]','UCiUP58QbiDO7lj6dZXJU-fw','PL6YXmKMvrmg21Nbk3o4SUirDQbpHL1k8n',1,0,'2015-05-17 15:30:16','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(36,'Let\'s Play The Witcher 3: Wild Hunt [BLIND]','UC3R3FltLbDk3bpCMZiCloUQ','PLvqxe4XbcSiFpypC3QawaVxrtJZP0meJL',1,0,'2015-06-13 17:21:40','2015-07-25 17:01:05','2015-07-25 17:01:05'),
	(37,'Let\'s Play The Witcher (Enhanced Edition)','UCdAy0KqpdA2Lp2_Qp0yNk2g','PLj_Goi54wf0f2NXPeIvJqtLBSG9_nBTMM',1,0,'2013-05-01 12:58:23','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(38,'THE WITCHER 3: Wild Hunt | LET\'S PLAY ESPAÑOL','UCz9SoWLJhhoGAs_5NGfVVMA','PLJA-F27tJiFsoLiIHJZRxc6L6m3SecWMe',1,0,'2015-05-20 13:24:29','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(39,'The Witcher 3 - Let\'s Play','UCMCprdjz7S-kJZopeEIhh2Q','PLGAk8cmzzAdFj0yZz_cdZXmy7-MBHBihH',1,0,'2015-05-19 20:31:06','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(40,'Witcher 3 - Let\'s Play','UCVHtlynIkgJxxXrisVUZlYQ','PLlwKCy51_4YjApVFhUiQzW2JXAKDvmiM1',1,0,'2015-05-19 13:46:54','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(41,'The Witcher 3','UCKJFm7hOPvqXZxkcUFbe6mg','PL4lAj-XYeU9qiMT7Tg-YA4Fem64V1BF02',1,0,'2015-05-18 20:52:45','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(42,'Let\'s Play The Witcher 3 Wild Hunt [HD]','UCA0MDADBWmCFro3SXR5mlSg','PLOCsrhzPYNpOyJQClUDc1U2R4qsuXL1A4',1,0,'2015-05-16 11:55:36','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(43,'Witcher 3: Let\'s play GWENT','UClocwqff8QZXCWAAG3qXdIA','PLg-3fyNFM8DBa48Nw-MBkY21t5b7MJcDl',1,0,'2015-06-01 17:27:53','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(44,'The Witcher 3 Wild Hunt - Gameplay Walkthrough Let\'s Play  ITA','UCA9EBiQ78vhvl5Y_AAfp_sw','PLsY_BSJqWnbkt4rTrfu4yBIQybI32ytdV',1,0,'2015-05-15 20:03:43','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(45,'Let\'s Play | The Witcher 3: Wild hunt','UCwfUPrX0TOzKD3yOh41jwtQ','PLOLjEB4MH70jltNqEW4lHfNXJ2u72uRTe',1,0,'2015-05-19 20:10:16','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(46,'Let\'s Play THE WITCHER 3','UCod274RhciJ8RU8CnZXKu8A','PLyy03f5334jMlDJdsClapRWRXFe_uLEV_',1,0,'2015-05-19 19:29:14','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(47,'Let\'s Play The Witcher 3 Wild Hunt','UCI6KPxFCu8JR5W7I6YCdzxA','PLeMCN2BKmfMeTBkS9u559q2I-C0YiPV_I',1,0,'2015-05-17 15:51:54','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(48,'The Witcher - Enhanced Edition','UC1CSCMwaDubQ4rcYCpX40Eg','PLE7DlYarj-DftNAlzoYNWYfKofD0FHpYk',1,0,'2014-10-06 15:12:31','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(49,'The Witcher 3 with EvilViking13: Trailers, reviews and Let\'s Plays','UCVigL0Gl6SYp0TifenNYY6A','PLEoKsmldPgw0xOzYF_84I2ve2UUgTdMpD',1,0,'2015-05-19 16:08:23','2015-07-25 17:01:06','2015-07-25 17:01:06'),
	(50,'Witcher 3: Wild Hunt Lets Play','UC2f0JypboD9nEbMIIE00AIQ','PLGJ-Rk8rcCMP_qSnG57qXol5-wSnAjvUy',1,0,'2015-05-19 21:00:30','2015-07-25 17:01:06','2015-07-25 17:01:06');

/*!40000 ALTER TABLE `series` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table series_video
# ------------------------------------------------------------

DROP TABLE IF EXISTS `series_video`;

CREATE TABLE `series_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `video_id` int(11) NOT NULL,
  `series_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `name`, `email`, `google_id`, `avatar`, `token`, `remember_token`, `created_at`, `updated_at`)
VALUES
	(1,'Anonymous',NULL,'0','none','none',NULL,'2015-07-25 16:57:20','2015-07-25 16:57:20'),
	(2,'Daniel Dunderfelt',NULL,'UCJwpEsOOuvwIsuqykYf08eg','https://yt3.ggpht.com/-bhvPPaddiow/AAAAAAAAAAI/AAAAAAAAAAA/C-nwUVrBK-Y/s240-c-k-no/photo.jpg','ya29.uwFZd_EiWPaneT_d_YDvxsIxWN8tMJkxW31_9dxg6OnTWe5Dqc0dmNH5TnKSdTGqV8oEyQ','R1yJlU7g9loujNLjlmgIDHX1qIWoxIYJQIBJZjEwXOCTPsMe9iKUbeAGkcYs','2015-07-25 16:59:13','2015-07-25 16:59:13');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table videos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `videos`;

CREATE TABLE `videos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `video_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creator_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `published_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `videos_video_id_unique` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
